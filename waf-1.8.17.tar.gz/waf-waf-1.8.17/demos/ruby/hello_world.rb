puts 'hello world'
#require 'hello2'
