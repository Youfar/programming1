
package org.example;

import org.example.Animal;

class Cat extends Animal {

    public String sound() {
            return "Meow!";
    }
           

}

