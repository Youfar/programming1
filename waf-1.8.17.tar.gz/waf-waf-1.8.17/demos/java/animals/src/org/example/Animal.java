package org.example;

class Animal {

    public String sound() {
            return null;
    }

}
