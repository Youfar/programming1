package org.example;

import junit.framework.TestCase;

public class AnimalTest extends TestCase {
	public AnimalTest() {
	}

	public void testAnimal() {
		System.out.println("Test run successfully!");
	}
}

