package org.test; // obligatory

public class Hella
{
	public static void main(String args[])
	{
		System.out.println("Hella, world");
	}
}

