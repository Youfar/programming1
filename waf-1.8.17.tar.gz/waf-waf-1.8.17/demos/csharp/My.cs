public class My {
	private Dye foo;

	public My(string msg) {
		foo = new Dye(msg);
	}

	public void display() {
		foo.display();
	}
}
