namespace MyApp
{
	using System;

	public class Hi
	{
		public static int Main(string[] args)
		{
			My fu = new My("Hello there");
			fu.display();
			return 0;
		}
	}
}

