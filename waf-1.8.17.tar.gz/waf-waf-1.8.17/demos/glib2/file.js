print('This is a resource file!')
