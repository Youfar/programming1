/* Some test enums */

typedef enum {
	WAF = 1,
	AUTOTOOLS = 2,
	SCONS = 3,
	CMAKE = 4,
	JAM = 5
} BuildSystemType;
