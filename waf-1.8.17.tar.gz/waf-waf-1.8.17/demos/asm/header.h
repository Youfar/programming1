#define SOME_VALUE 0x1a5
