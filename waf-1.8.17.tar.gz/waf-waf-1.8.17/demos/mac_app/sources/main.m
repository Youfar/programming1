// waf sample Mac application - main.m
// Chris Pickel, 2011

#import <Cocoa/Cocoa.h>

int main(int argc, const char* argv[]) {
    return NSApplicationMain(argc, argv);
}
