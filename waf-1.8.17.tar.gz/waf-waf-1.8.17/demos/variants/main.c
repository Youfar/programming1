
#include "config.h"

#if A
int main() {
	return 0;
}
#endif
