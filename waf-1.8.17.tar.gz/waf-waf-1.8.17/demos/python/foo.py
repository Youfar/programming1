
zbr = "bar"

assert zbr

