#include <string>

class TestClass
{
public:
	std::string message();
};