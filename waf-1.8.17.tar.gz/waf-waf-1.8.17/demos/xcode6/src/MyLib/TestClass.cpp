#include "MyLib/TestClass.h"

std::string TestClass::message() {
	return "Hello from TestClass";
}