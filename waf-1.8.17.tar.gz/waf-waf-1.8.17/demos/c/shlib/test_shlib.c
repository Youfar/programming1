
static const int truc=5;

void foo() { }
void _internal() {} /* this one is not gonna be exported by *.def */
