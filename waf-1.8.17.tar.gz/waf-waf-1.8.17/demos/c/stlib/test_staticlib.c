int k = 3;

