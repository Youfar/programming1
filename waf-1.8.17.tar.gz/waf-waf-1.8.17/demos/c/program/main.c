#include "a.h"
#include "b.h"
#include "config.h"

#include "abc.h"

int main() {
	return 0;
}
