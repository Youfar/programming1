#include "a.h"

int main() {
	test();
	return 0;
}
