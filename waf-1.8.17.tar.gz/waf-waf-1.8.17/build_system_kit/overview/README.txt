See the corresponding entry on the waf blog:
http://waf-devel.blogspot.com/2010/12/make-your-own-build-system-with-waf.html

To create the build tool:
   ./create_it.sh

To use on the file bbit which creates a program out of main.c:
   ./bbd clean build

Enjoy your new build system! :-)

