This example derives from the 'overview' and demonstrates how to provide
a parser for a make-like language.

The script files read are named 'cbit'

To create the build tool:
   ./create_it.sh

To use on the file cbit which creates a program out of main.c:
   ./cbd clean build

