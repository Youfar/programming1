#include "foo.h"
#include <stdio.h>
int main() {
	printf("hello from app\n");
	return 0;
}
