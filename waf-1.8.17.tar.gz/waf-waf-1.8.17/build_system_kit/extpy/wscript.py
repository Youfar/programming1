#! /usr/bin/env python
# encoding: utf-8

def configure(conf):
	print("test succeeded")
