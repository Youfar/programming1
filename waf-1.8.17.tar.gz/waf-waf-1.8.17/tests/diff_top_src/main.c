#include <stdio.h>

int main() {
    printf("Howdy!\n");
	return 0;
}
