//#include "bar.h"
int main() { return 0; }
