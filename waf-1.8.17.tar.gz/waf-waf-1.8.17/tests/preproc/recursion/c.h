#undef FOO
#undef BAR
#include "a.h"
