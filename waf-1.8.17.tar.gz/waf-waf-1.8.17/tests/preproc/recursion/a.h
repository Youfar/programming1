#ifdef FOO
#include "c.h"
#endif

#ifdef BAR
#include "b.h"
#endif

