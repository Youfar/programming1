int main() {
	return 0;
}

#ifndef REQ
  #error required
#endif

#ifdef NREQ
  #error not required
#endif

