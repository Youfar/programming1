#include "my_include.hpp"

#include <string>

int main()
{
	std::string test;
}
