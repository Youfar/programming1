#ifndef GUARD
#define GUARD

class my_class {
public:
    my_class() {}
};

#endif
