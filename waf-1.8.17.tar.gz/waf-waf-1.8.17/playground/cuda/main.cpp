#include <stdio.h>

#include "test.h"

int main()
{
	testcuda();
	return 0;
}
