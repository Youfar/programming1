int testcuda();
