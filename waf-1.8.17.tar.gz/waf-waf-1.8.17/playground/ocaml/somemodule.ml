open Printf;;

let pprint str =
	Printf.printf "* %s" str
;;


