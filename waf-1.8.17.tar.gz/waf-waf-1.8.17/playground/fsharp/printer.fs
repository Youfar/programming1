
#light
module Printer
let print_repeatedly n str = for x in 1..n do printfn "%s" str
