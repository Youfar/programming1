
#light
module Main
let main = Printer.print_repeatedly 5 "hello, world"
