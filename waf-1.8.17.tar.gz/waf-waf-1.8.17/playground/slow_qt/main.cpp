// Thomas Nagy, 2011

#include <QApplication>

int main(int argc, char *argv[])
{
	return 0;
}
