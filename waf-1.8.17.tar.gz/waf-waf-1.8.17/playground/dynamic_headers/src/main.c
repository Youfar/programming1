#include "mock_module.h"

int main(void)
{
    return 0;
}

