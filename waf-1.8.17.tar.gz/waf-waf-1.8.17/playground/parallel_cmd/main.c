#include <stdio.h>

int main() {
	printf("A=%d\n", A);
	return 0;
}

