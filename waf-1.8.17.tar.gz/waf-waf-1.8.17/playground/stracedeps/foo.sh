#! /bin/sh

set -e
cd /etc
cat fstab > /dev/null

