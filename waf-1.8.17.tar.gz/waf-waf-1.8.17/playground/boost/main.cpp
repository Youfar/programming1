#include <boost/filesystem.hpp>

int main()
{
	boost::filesystem::path my_path("c:\\");
	return 0;
}
