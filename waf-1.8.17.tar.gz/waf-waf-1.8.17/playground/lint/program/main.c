#include "a.h"
#include "b.h"

int main() {
	return 0;
}
