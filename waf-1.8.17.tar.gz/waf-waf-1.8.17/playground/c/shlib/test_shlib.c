
static const int truc=5;

void foo() { }

