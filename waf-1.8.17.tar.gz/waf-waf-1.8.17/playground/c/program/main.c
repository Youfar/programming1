#include "a.h"
#include "config.h"
int main() {
	return 0;
}
