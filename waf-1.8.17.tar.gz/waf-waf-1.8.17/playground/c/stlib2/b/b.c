#include "a.h"

int b()
{
    return a() + 1;
}
