#include <foo.h>
void foo() {}
