int u = 0;
