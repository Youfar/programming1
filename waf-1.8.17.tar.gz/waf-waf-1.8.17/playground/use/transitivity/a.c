#include "stdio.h"
#include <zlib.h>
#include "a.h"

void a() {
	gzFile f = gzopen("test.gz", "wb9");
}

