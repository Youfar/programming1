#include "a.h"

void b () {
	a();
}

