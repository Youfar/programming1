extern void a();

