#include "b.h"

int main() {
	b();
}
