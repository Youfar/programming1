#include "a.h"

int main() {
	a();
}
