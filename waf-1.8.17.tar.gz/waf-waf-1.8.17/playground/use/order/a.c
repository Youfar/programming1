#include "a.h"

int aaa() {
	return 33;
}

