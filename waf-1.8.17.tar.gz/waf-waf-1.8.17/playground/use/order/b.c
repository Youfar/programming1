
#include "a.h"

int bbb() {
	return aaa();
}

