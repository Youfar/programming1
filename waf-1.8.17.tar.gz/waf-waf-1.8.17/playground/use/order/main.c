int main() {
	bbb();
	return 0;
}
