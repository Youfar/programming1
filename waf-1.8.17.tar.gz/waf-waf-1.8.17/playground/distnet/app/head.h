#ifndef pouet
	#error "project not configured properly"
#endif

int foo();
