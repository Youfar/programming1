#! /bin/sh

python -m CGIHTTPServer

