#include "head.h"

int main()
{
	return 0;
}
