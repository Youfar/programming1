public class Hi {
	public Hi() {
		System.out.println("hi");
	}
}
