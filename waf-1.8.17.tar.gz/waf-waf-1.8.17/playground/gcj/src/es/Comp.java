package es;

public class Comp {
	public static final String WAF = "-.-.-.-.-";
}
