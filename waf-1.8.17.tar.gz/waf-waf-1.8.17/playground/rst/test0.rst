#########
Example 0
#########

:purpose: demonstrate very basic rst processing

.. figure:: test.svg
   :align: center
   :width: 50%

   This is a static svg file

