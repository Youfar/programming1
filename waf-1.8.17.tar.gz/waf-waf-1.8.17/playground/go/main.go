// By: Tom Wambold <tom5760@gmail.com>
package main

import "other"

func main() {
    a := other.Vector3 {1, 2, 3};
    a.Size();
    return;
}
