package main

import "foo"

func main() {
	foo.MyHello("hello from my-c-lib\n")
	foo.MyBye("bye from my-c-lib\n")
}

// EOF
