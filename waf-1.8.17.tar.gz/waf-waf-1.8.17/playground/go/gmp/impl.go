package gmp

/*
 #include <stdio.h>
*/
import "C"
// EOF
