package other

type Foo interface {
    Get(i int, j int) float64;
    Set(i int, j int, v float64);
}
