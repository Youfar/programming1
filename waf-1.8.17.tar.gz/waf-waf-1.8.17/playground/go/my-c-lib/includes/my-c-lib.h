#ifndef MY_C_LIB_H
#define MY_C_LIB_H 1

void my_c_hello(const char *msg);
void my_c_bye(const char *msg);

#endif
