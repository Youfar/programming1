#if A == 1

#include "external.h"

int main() {
	return zero();
}

#endif

