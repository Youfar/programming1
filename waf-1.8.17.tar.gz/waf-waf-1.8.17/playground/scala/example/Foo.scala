package example;

object Foo {
	def main(args: Array[String]) {
		println("Hello, Foo!")
	}
}

