/*!
 * Unused class for demo a.h
 */
class foo
{
	private:
		/*!
		 * attribute x, hmmm :-)
		 */
		int x;

	public:
		/*!
		 * i love comments such as "this is a constructor"
		 */
		foo();

		/*!
		 * float y, tadam
		 */
		float y;
};


