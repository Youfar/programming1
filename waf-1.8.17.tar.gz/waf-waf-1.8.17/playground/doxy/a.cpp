#include "a.h"

foo::foo()
{

}

