/*!
 * Nothing to hide, so all is public
 */
class meep
{
	public:
		/*!
		 * attribute a, hmmm :-)
		 */
		int a;

		/*!
		 * no comments
		 */
		meep();
};


