#include "b.h"

bar::bar()
{

}

int main()
{
	return 1;
}

