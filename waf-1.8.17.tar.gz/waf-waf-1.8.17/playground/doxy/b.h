
/*!
 * pim pam
 */
class bar
{
	private:
		/*!
		 * zzzz
		 */
		int z;

	public:
		/*!
		 * guess what this is .. a constructor?
		 */
		bar();

		/*!
		 * out of ideas for comments
		 */
		float t;
};

