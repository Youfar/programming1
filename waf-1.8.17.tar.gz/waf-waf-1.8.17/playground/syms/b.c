int mylib_bb() {
	return 48;
}
int internal_bb() {
	return 64;
}
