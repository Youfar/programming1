int mylib_aa() {
	return 32;
}
int internal_aa(){
	return 16;
}
