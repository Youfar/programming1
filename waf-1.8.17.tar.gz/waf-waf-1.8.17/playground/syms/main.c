#include <stdio.h>
int mylib_aa();
int mylib_bb();
int main() {
	printf("aa() = %d", mylib_aa());
	printf("bb() = %d", mylib_bb());
	return 0;
}
