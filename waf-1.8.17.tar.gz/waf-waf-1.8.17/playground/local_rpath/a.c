int k=43234;
