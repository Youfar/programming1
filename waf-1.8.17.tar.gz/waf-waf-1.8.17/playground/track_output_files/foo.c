int kkk() {return 0; }
