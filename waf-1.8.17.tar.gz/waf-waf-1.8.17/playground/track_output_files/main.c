
extern int kkk();
int main() {
	return kkk();
}
