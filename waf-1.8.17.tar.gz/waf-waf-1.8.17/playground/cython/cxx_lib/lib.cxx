#include "lib.h"
#include <iostream>


void hello(void)
{
  std::cout << "Hello, C++-world!" << std::endl;
}
