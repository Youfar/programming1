#include "lib.h"
#include <stdio.h>


void hello(void)
{
  printf("Hello, C-world!\n");
}
