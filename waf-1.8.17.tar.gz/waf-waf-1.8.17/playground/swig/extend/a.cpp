#include "a.h"

A::A( ) { }

A::~A( ) { }

int A::add(int a, int b) {
	return a + b;
}

