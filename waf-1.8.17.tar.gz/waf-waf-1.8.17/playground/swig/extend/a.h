#ifndef A_H
#define A_H

class A {
	public:
		A();
		~A();

	int add(int a, int b);
};

#endif  /* A_H */

