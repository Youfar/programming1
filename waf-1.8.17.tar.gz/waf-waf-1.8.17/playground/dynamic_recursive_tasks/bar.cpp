#include "truc.h"

void bar() {

}

