void truc() {

}
