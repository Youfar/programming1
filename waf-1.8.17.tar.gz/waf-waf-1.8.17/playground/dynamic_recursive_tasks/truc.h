void truc();
