#include "bar.h"
#include "truc.h"

void test() {

}

