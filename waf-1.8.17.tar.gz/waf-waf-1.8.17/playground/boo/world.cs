public class World {
	public static void SayHello()
	{
		System.Console.WriteLine("Hello from C#");
	}
}
