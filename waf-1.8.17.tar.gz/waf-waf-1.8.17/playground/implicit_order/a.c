int ki = 33;
