#ifndef B_H
#define B_H

#warning "testpch: b.h"

#ifdef HAS_MY_BOOST
	#include <boost/asio.hpp>
#endif

#endif // B_H
