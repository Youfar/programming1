#include "a.h"
#include "b.h"
#include "c.h"

int main()
{
	return 0;
}
