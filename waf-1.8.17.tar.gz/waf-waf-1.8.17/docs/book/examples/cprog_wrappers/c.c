int c = 32;
