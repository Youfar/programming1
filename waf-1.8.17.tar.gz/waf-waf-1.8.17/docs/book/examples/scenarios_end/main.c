#include "a.h"

int main() {
	ping();
	return 0;
}

 
