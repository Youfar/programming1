#include <stdio.h>
#include <a.h>

void ping() {
	printf("Project compiled: %s %s\n", __DATE__, __TIME__);
}
