int k;

int main() {
	return k;
}
