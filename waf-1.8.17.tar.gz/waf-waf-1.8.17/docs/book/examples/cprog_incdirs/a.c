#include "a.h"

int foo() {
	return ke;
}
