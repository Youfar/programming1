int ke = 55;
