.. _about:

About this documentation
------------------------

These documents are generated from `reStructuredText`_ sources by `Sphinx`_, a
document processor specifically written for the Python documentation.

.. _reStructuredText: http://docutils.sf.net/rst.html
.. _Sphinx: http://sphinx.pocoo.org/

The development of the documentation takes place on the mailing-list
http://groups.google.com/group/waf-users.  We are always looking for volunteers wanting
to help with the docs, so feel free to send a mail there!

