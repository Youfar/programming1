Errors
------

.. automodule:: waflib.Errors

