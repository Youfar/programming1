Context
---------

.. automodule:: waflib.Context

