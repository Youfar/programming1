Scripting
---------

.. automodule:: waflib.Scripting

