Options
-------

.. automodule:: waflib.Options

