Configure
---------

.. automodule:: waflib.Configure

