from setuptools import setup, find_packages
setup(
	name = "smith",
	version = "1.0",
	packages = find_packages(),
	scripts = ['smith_waterman.py'],
)
